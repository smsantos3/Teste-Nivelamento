﻿using Microsoft.EntityFrameworkCore;
using Questao5.Infrastructure.Database.Models;

namespace Questao5.Infrastructure.Database
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Contacorrente> contacorrente { get; set; }
        public DbSet<Movimento> movimento { get; set; }
        public DbSet<Idempotencia> idempotencia { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Contacorrente>().HasKey(am => new
            {
                am.idcontacorrente
            });

            modelBuilder.Entity<Movimento>().HasKey(am => new
            {
                am.idmovimento
            });

            modelBuilder.Entity<Idempotencia>().HasKey(am => new
            {
                am.chave_idempotencia
            });

        }

    }
}
