﻿using Microsoft.EntityFrameworkCore;
using Questao5.Infrastructure.Database.Models;

namespace Questao5.Infrastructure.Database
{
    public class Repositorio : IRepositorio
    {
        private readonly DataContext _context;
        public Repositorio(DataContext context)
        {
            _context = context;
        }

        public Contacorrente[] GetContaCorrente(int numeroContaCorrente)
        {

            var query = _context.contacorrente.Where(x => x.numero == numeroContaCorrente).ToList();

            return query.ToArray();
        }

        public Movimento[] GetMovimentoContaCorrente(string idContaCorrente)
        {

            var query = _context.movimento.Where(x => x.idcontacorrente == idContaCorrente).ToList();

            return query.ToArray();
        }

        public void Add<T>(T entity) where T : class
        {
            _context.Add(entity);
        }
        public bool SaveChanges()
        {
            return (_context.SaveChanges() > 0);
        }

    }
}
