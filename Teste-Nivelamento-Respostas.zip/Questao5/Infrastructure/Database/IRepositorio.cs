﻿using Questao5.Infrastructure.Database.Models;

namespace Questao5.Infrastructure.Database
{
    public interface IRepositorio
    {
        Contacorrente[] GetContaCorrente(int numeroContaCorrente);
        Movimento[] GetMovimentoContaCorrente(string idContaCorrente);
        void Add<T>(T entity) where T : class;
        bool SaveChanges();

    }
}
