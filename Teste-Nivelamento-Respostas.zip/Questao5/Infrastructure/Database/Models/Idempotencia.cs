﻿using System;
using System.Collections.Generic;
namespace Questao5.Infrastructure.Database.Models
{
    public class Idempotencia
    {
        public Idempotencia() { }
        public Idempotencia(
                    string Chave_idempotencia,
                    string Requisicao,
                    string Resultado
                    )
        {
            this.chave_idempotencia = Chave_idempotencia;
            this.requisicao = Requisicao;
            this.resultado = Resultado;
        }
        public string chave_idempotencia { get; set; }
        public string requisicao { get; set; }
        public string resultado { get; set; }
    };

}
