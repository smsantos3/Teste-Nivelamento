﻿using System;
using System.Collections.Generic;
namespace Questao5.Infrastructure.Database.Models
{
    public class Contacorrente
    {
        public Contacorrente() { }
        public Contacorrente(
                    string Idcontacorrente, 
                    int Numero,
                    string Nome,
                    int Ativo
                    )
        {
            this.idcontacorrente = Idcontacorrente;
            this.numero = Numero;
            this.nome = Nome;
            this.ativo = Ativo;
        }
        public string idcontacorrente { get; set; }
        public int numero { get; set; }
        public string nome { get; set; }
        public int ativo { get; set; }
    };

}
