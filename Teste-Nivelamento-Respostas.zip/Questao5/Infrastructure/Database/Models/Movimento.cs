﻿using System;
using System.Collections.Generic;
namespace Questao5.Infrastructure.Database.Models
{
    public class Movimento
    {
        public Movimento() { }
        public Movimento(
                    string Idmovimento,
                    string Idcontacorrente,
                    string Datamovimento,
                    string Tipomovimento,
                    double Valor
                    )
        {
            this.idmovimento = Idmovimento;
            this.idcontacorrente = Idcontacorrente;
            this.datamovimento = Datamovimento;
            this.tipomovimento = Tipomovimento;
            this.valor = Valor;
        }
        public string idmovimento { get; set; }
        public string idcontacorrente { get; set; }
        public string datamovimento { get; set; }
        public string tipomovimento { get; set; }
        public double valor { get; set; }
    };

}
