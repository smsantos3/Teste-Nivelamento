using Microsoft.AspNetCore.Mvc;
using Questao5.Infrastructure.Database;
using Questao5.Infrastructure.Database.Models;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MovContaCorrenteController : ControllerBase
    {
        private readonly ILogger<MovContaCorrenteController> _logger;
        public readonly IRepositorio _repo;

        public MovContaCorrenteController(ILogger<MovContaCorrenteController> logger, IRepositorio repo)
        {
            _logger = logger;
            _repo = repo;
        }

        /// <summary>
        /// Movimenta��o de Contas Correntes
        /// </summary>
        /// <remarks>
        /// Realiza��o movimenta��o de cr�dito e d�bito em contas correntes
        /// </remarks>
        /// <param name="idRequisicao">
        /// Identificador da requisi��o
        /// </param>
        /// <param name="numeroContaCorrente">
        /// N�mero da conta corrente
        /// </param>
        /// <param name="valorMovimentacao">
        /// Valor da movimenta��o
        /// </param>
        /// <param name="tipoMovimento">
        /// tipo do movimento. (C = Credito, D = Debito) 
        /// </param>
        /// <returns></returns>
        /// <response code="200">* Retorna no body Id do movimento gerado</response>
        /// <response code="400">Retorna erros de valida��o
        /// * Apenas contas correntes cadastradas podem receber movimenta��o; TIPO: INVALID_ACCOUNT.
        /// * Apenas contas correntes ativas podem receber movimenta��o; TIPO: INACTIVE_ACCOUNT.
        /// * Apenas valores positivos podem ser recebidos; TIPO: INVALID_VALUE.
        /// * Apenas os tipos �d�bito� ou �cr�dito� podem ser aceitos; TIPO: INVALID_TYPE.
        /// </response>
        [HttpPost(Name = "PostMovContaCorrente")]
        public IActionResult Post(string idRequisicao, int numeroContaCorrente, 
                                  double valorMovimentacao, string tipoMovimento)
        {
            try
            {
                var conta = _repo.GetContaCorrente(numeroContaCorrente).FirstOrDefault();
                if (conta == null)
                    throw new Exception("TIPO: INVALID_ACCOUNT");
                else
                {
                    if (int.Parse(conta.ativo.ToString()) == 0)
                        throw new Exception("TIPO: INACTIVE_ACCOUNT");
                    else
                    {
                        if (valorMovimentacao < 0.01)
                            throw new Exception("TIPO: INVALID_VALUE");
                        else
                        {
                            if (!(tipoMovimento.ToUpper() == "D" || tipoMovimento.ToUpper() == "C"))
                                throw new Exception("TIPO: INVALID_TYPE");
                            else
                            {
                                var movimento = new Movimento
                                {
                                    idmovimento = idRequisicao,
                                    idcontacorrente = conta.idcontacorrente.ToString(),
                                    datamovimento = DateTime.Now.ToString("dd-MM-yyyy"),
                                    tipomovimento = tipoMovimento.ToUpper(),
                                    valor = valorMovimentacao
                                };
                                _repo.Add(movimento);
                                if (_repo.SaveChanges())
                                    return Ok(
                                            new
                                                {idmovimento = movimento.idmovimento.ToString()
                                                }
                                            );
                                else
                                    throw new Exception("AO GRAVAR A MOVIMENTA��O");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest($"Erro: {ex.Message}");
            }
        }

    }
}
