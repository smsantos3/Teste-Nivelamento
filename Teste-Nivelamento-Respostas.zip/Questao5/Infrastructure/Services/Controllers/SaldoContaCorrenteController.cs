using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Questao5.Infrastructure.Database;
using Questao5.Infrastructure.Database.Models;
using System.Diagnostics.Eventing.Reader;

namespace Questao5.Infrastructure.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SaldoContaCorrenteController : ControllerBase
    {
        private readonly ILogger<SaldoContaCorrenteController> _logger;
        public readonly IRepositorio _repo;

        public SaldoContaCorrenteController(ILogger<SaldoContaCorrenteController> logger, IRepositorio repo)
        {
            _logger = logger;
            _repo = repo;
        }

        /// <summary>
        /// Saldo de Contas Correntes
        /// </summary>
        /// <remarks>
        /// consulta saldo de Contas Correntes
        /// </remarks>
        /// <param name="numeroContaCorrente">
        /// N�mero da conta corrente
        /// </param>
        /// <returns></returns>
        /// <response code="200">
        /// * N�mero da conta corrente
        /// * Nome do titular da conta corrente
        /// * Data e hora da resposta da consulta
        /// * Valor do Saldo atual
        /// </response>
        /// <response code="400">Retorna erros de valida��o
        /// * Apenas contas correntes cadastradas podem consultar o saldo; TIPO: INVALID_ACCOUNT.
        /// * Apenas contas correntes ativas podem consultar o saldo; TIPO: INACTIVE_ACCOUNT.
        /// </response>

        [HttpGet(Name = "GetSaldoContaCorrente")]
        public IActionResult Get(int numeroContaCorrente)
        {
            try
            {
                var conta = _repo.GetContaCorrente(numeroContaCorrente).FirstOrDefault();
                if (conta == null)
                    throw new Exception("TIPO: INVALID_ACCOUNT");
                else
                {
                    if(int.Parse(conta.ativo.ToString())==0)
                        throw new Exception("TIPO: INACTIVE_ACCOUNT");
                    else
                    {
                        double saldoAtual = 0;
                        var movimento = _repo.GetMovimentoContaCorrente(conta.idcontacorrente.ToString()).ToList();

                        if (!(movimento == null || movimento.Count() == 0))
                        {
                            var movimentoDebito  = (from mv in movimento
                                                   where mv.tipomovimento == "D"
                                                   select mv.valor).Sum();

                            var movimentoCredito = (from mv in movimento
                                                   where mv.tipomovimento == "C"
                                                   select mv.valor).Sum();

                            saldoAtual = movimentoCredito - movimentoDebito;
                        }

                        return Ok(new
                        {
                            NumeroContaCorrente = conta.numero.ToString(),
                            NomeTitular = conta.nome.ToString(),
                            DataHoraConsulta = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss"),
                            SaldoAtual = saldoAtual
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                return BadRequest($"Erro: {ex.Message}");
            }
        }
    }
}