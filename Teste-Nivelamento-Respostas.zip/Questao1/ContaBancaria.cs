﻿using System;
using System.Globalization;

namespace Questao1
{
    class ContaBancaria
    {
        public ContaBancaria(int numero, string titular, double depositoInicial=0)
        {
            Numero = numero;
            Titular = titular;
            Saldo = depositoInicial;
        }

        public int Numero { get; }
        public string Titular { get; set; }
        public double Saldo { get; private set; }
        internal void Deposito(double quantia)
        {
            Saldo += quantia;
        }

        internal void Saque(double quantia)
        {
            Saldo -= quantia + 3.5;
        }

        public override string ToString()
        {
            return "Conta "
            + Numero
            + ", Titular: "
            + Titular
            + ", Saldo: $ "
            + Saldo.ToString("F2", CultureInfo.InvariantCulture);
        }
    }
}
